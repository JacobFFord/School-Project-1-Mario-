#include <cs50.h>
#include <stdio.h>

int main(void)
    
    
{
    int height = 0;
do
{
    height = get_int("pyramid height, must be an integer between 1 and 8: ");
}
    while (height < 1 || height > 8);
        
        if (height > 1 || height < 8)
        
    for (int row = 0; row < height; row++)
    {
        int spaces = height - row;
        int bricks = row + 1;
        
        for (int i = 1; i < spaces; i++)
        {
            printf(" ");
        }
        for (int i = 0; i < bricks; i++)
        {
            printf("#");
        }
        printf("\n");
    }
        
  
       
}
